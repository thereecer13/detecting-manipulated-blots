import json,cv2,numpy as np,sys
from collections import Counter
src,out=sys.argv[1],sys.argv[2];seen=set(json.load(open(sys.argv[3]))) if len(sys.argv)>3 else set()
d=json.load(open(src));H=[r for r in d if isinstance(r['found'],list) and r['found'] and r['file'] not in seen]
print(len(d),'scanned;',len(H),'new flagged images')
print(Counter({r['catalog']+' '+r['image_url'].split('IHC')[-1]:len(r['found']) for r in H}))
rows=[(f,r) for r in H for f in r['found'] if len(r['found'])<=4 and f['area']>=200];rows.sort(key=lambda t:-t[0]['area']);tiles=[]
for i,(f,r) in enumerate(rows):
    im=cv2.imread('ptg_ihc/images/'+r['file']);Hh,W=im.shape[:2];s=1024/max(Hh,W)
    if s<1: im=cv2.resize(im,(round(W*s),round(Hh*s)),interpolation=cv2.INTER_AREA)
    x,y,w,h=f['bbox'];dx,dy=f['shift'];p=22
    x0=max(0,x-p,-dx);y0=max(0,y-p,-dy);x1=min(im.shape[1],x+w+p,im.shape[1]-dx);y1=min(im.shape[0],y+h+p,im.shape[0]-dy)
    if x1-x0<8 or y1-y0<8: continue
    A=im[y0:y1,x0:x1];B=im[y0+dy:y1+dy,x0+dx:x1+dx]
    df=np.clip(np.abs(A.astype(np.float32)-B).max(2)*4,0,255).astype(np.uint8);D=cv2.cvtColor(255-df,cv2.COLOR_GRAY2BGR)
    t=np.hstack([A,B,D]);sc=min(220/t.shape[0],720/t.shape[1]);t=cv2.resize(t,None,fx=sc,fy=sc,interpolation=cv2.INTER_NEAREST)
    c=np.full((244,720,3),255,np.uint8);c[22:22+t.shape[0],:t.shape[1]]=t
    cv2.putText(c,f"{i} {r['catalog']} {r['image_url'].split('IHC')[-1]} a{f['area']} in{f['inside']} ring{f['ring']} {f['shift']} n{len(r['found'])}",(2,15),0,0.45,(0,0,0),1,cv2.LINE_AA);tiles.append(c)
for p in range(0,len(tiles),12):
    ch=tiles[p:p+12];rw=[np.hstack(ch[q:q+2]+[np.full((244,720,3),255,np.uint8)]*(2-len(ch[q:q+2]))) for q in range(0,len(ch),2)]
    cv2.imwrite(f'{out}{p//12}.jpg',np.vstack(rw))
print(len(tiles),'tiles (images with <=4 blocks, block >=200 px)')
